package com.hyr.demo;

public class PolData {
	public String getPol() {
		return pol;
	}
	public void setPol(String pol) {
		this.pol = pol;
	}
	public String getKeiyaName() {
		return keiyaName;
	}
	public void setKeiyaName(String keiyaName) {
		this.keiyaName = keiyaName;
	}
	public String getHiName() {
		return hiName;
	}
	public void setHiName(String hiName) {
		this.hiName = hiName;
	}
	public String getMasterKeiya() {
		return masterKeiya;
	}
	public void setMasterKeiya(String masterKeiya) {
		this.masterKeiya = masterKeiya;
	}
	public String getLnnnTokuyaku() {
		return lnnnTokuyaku;
	}
	public void setLnnnTokuyaku(String lnnnTokuyaku) {
		this.lnnnTokuyaku = lnnnTokuyaku;
	}
	public String getMenjyoToku() {
		return menjyoToku;
	}
	public void setMenjyoToku(String menjyoToku) {
		this.menjyoToku = menjyoToku;
	}
	public String getToriField() {
		return toriField;
	}
	public void setToriField(String toriField) {
		this.toriField = toriField;
	}
	public String getToriKind() {
		return toriKind;
	}
	public void setToriKind(String toriKind) {
		this.toriKind = toriKind;
	}
	public String getToriName() {
		return toriName;
	}
	public void setToriName(String toriName) {
		this.toriName = toriName;
	}
	public String getKashiDate() {
		return kashiDate;
	}
	public void setKashiDate(String kashiDate) {
		this.kashiDate = kashiDate;
	}
	public String getAplCap() {
		return aplCap;
	}
	public void setAplCap(String aplCap) {
		this.aplCap = aplCap;
	}
	public String getAplCapUnit() {
		return aplCapUnit;
	}
	public void setAplCapUnit(String aplCapUnit) {
		this.aplCapUnit = aplCapUnit;
	}
	public String getPlCap() {
		return plCap;
	}
	public void setPlCap(String plCap) {
		this.plCap = plCap;
	}
	public String getPlCapUnit() {
		return plCapUnit;
	}
	public void setPlCapUnit(String plCapUnit) {
		this.plCapUnit = plCapUnit;
	}
	public String getPlInt() {
		return plInt;
	}
	public void setPlInt(String plInt) {
		this.plInt = plInt;
	}
	public String getPlIntUnit() {
		return plIntUnit;
	}
	public void setPlIntUnit(String plIntUnit) {
		this.plIntUnit = plIntUnit;
	}
	public String getAplInt() {
		return aplInt;
	}
	public void setAplInt(String aplInt) {
		this.aplInt = aplInt;
	}
	public String getAplIntUnit() {
		return aplIntUnit;
	}
	public void setAplIntUnit(String aplIntUnit) {
		this.aplIntUnit = aplIntUnit;
	}
	public String getTokuField() {
		return tokuField;
	}
	public void setTokuField(String tokuField) {
		this.tokuField = tokuField;
	}
	public String getTokuName() {
		return tokuName;
	}
	public void setTokuName(String tokuName) {
		this.tokuName = tokuName;
	}
	public String getGenkyo() {
		return genkyo;
	}
	public void setGenkyo(String genkyo) {
		this.genkyo = genkyo;
	}
	public String getMoneyTitle() {
		return moneyTitle;
	}
	public void setMoneyTitle(String moneyTitle) {
		this.moneyTitle = moneyTitle;
	}
	public String getMoneyAmount() {
		return moneyAmount;
	}
	public void setMoneyAmount(String moneyAmount) {
		this.moneyAmount = moneyAmount;
	}
	public String getKeiyaDate() {
		return keiyaDate;
	}
	public void setKeiyaDate(String keiyaDate) {
		this.keiyaDate = keiyaDate;
	}
	public String getFinishDate() {
		return finishDate;
	}
	public void setFinishDate(String finishDate) {
		this.finishDate = finishDate;
	}
	public String getDeclineSpan() {
		return declineSpan;
	}
	public void setDeclineSpan(String declineSpan) {
		this.declineSpan = declineSpan;
	}
	public String getNotInsuOrgan() {
		return notInsuOrgan;
	}
	public void setNotInsuOrgan(String notInsuOrgan) {
		this.notInsuOrgan = notInsuOrgan;
	}
	String pol;
	String keiyaName;
	String hiName;
	String masterKeiya;
	String lnnnTokuyaku;
	String menjyoToku;
	String toriField;
	String toriKind;
	String toriName;
	String kashiDate;
	String aplCap;
	String aplCapUnit;
	String plCap;
	String plCapUnit;
	String plInt;
	String plIntUnit;
	String aplInt;
	String aplIntUnit;
	String tokuField;
	String tokuName;
	String genkyo;
	String moneyTitle;
	String moneyAmount;
	String keiyaDate;
	String finishDate;
	String declineSpan;
	String notInsuOrgan;
}
